import matplotlib.pyplot as plt  # Package version: 3.5.3

plt.rcParams.update({'font.size': 11})
from copy import deepcopy
import sys
import numpy as np  # Package version: 1.21.6
import pandas as pd  # Package version: 1.3.5
import re
import math
import warnings
from scipy import stats  # Package version: 1.7.3
from sklearn.metrics import mean_squared_error, mean_absolute_error, mean_squared_error  # Package version: 1.0.2
from sklearn.metrics import r2_score
from linearmodels.panel import PanelOLS  # Package version: 4.15
from sklearn.preprocessing import MinMaxScaler
import tensorflow as tf  # Package version: 2.11.0
import os
from statsmodels.tsa.arima.model import ARIMA

# Suppress specific types of warnings
warnings.filterwarnings("ignore", category=FutureWarning)
warnings.filterwarnings("ignore", category=UserWarning)
warnings.filterwarnings("ignore", category=RuntimeWarning)
warnings.filterwarnings("ignore", message="A date index has been provided, but it has no")
warnings.filterwarnings("ignore", message="No supported index is available")
warnings.filterwarnings("ignore", message="indexing past lexsort depth may impact performance")
warnings.filterwarnings("ignore", message="tensorflow")
pd.set_option('mode.chained_assignment', None)
pd.set_option('display.max_columns', None)

# Display minus signs correctly
plt.rcParams['axes.unicode_minus'] = False
random_seed = 123

def panel_data_treat(original_data, panel_x, panel_y):
    """
    - Panel data preprocessing
    :param original_data: Original data
    :param panel_x: Features X in the panel data
    :param panel_y: Target Y in the panel data
    :return: Training and test sets with X lagged by one period and normalized
    """
    panel_data = original_data[['area', 'year', panel_y] + panel_x].dropna()

    # Use X from previous years to predict Y for the next year
    x_part = panel_data[['area', 'year'] + panel_x]
    y_part = panel_data[[panel_y, 'area', 'year']]

    x_part.loc[:, 'year'] = x_part['year'] + 1
    original_panel = y_part.merge(x_part, how='inner', on=['area', 'year'])


    # Normalization: fit using both training and test data together
    all_provence = list(set(original_panel.area))
    all_year = list(set(original_panel.year))
    all_year.sort()
    test_year = all_year.pop()
    original_panel = original_panel.set_index(['area', 'year'])
    scaler = MinMaxScaler()
    scaler_panel = pd.DataFrame(scaler.fit_transform(original_panel))
    scaler_panel.columns = original_panel.columns
    scaler_panel.index = original_panel.index

    #print(scaler_panel['gdp'])

    # Split into training and test data
    scaler_panel_train = scaler_panel.loc[(all_provence, all_year), :]
    scaler_panel_test = scaler_panel.loc[(all_provence, test_year), :]
    return scaler_panel_train, scaler_panel_test


def single_lstm(back_windows, x, test_x):
    """
    - Univariate LSTM: return processed data and model
    :param back_windows: Look-back window length
    :param x: Variable x in list form
    :param test_x:Test value of x
    :return: Return processed data and model structure
    """
    # 1. Ensure the look-back window does not exceed the series length
    assert back_windows < len(x)
    # 2. Construct data based on the look-back window
    ts_train = []
    for i in range(back_windows, len(x)):
        ts_train.append(x[i - 3:i])
    # Convert to a NumPy array
    ts_data = np.array(ts_train, dtype=np.float32)

    ts_test = x[len(x) - back_windows:-1] + [test_x]  # Append the test X
    ts_test = np.array(ts_test, dtype=np.float32)
    # 3. Standard LSTM model
    lstm_model = tf.keras.Sequential()
    lstm_model.add(tf.keras.layers.LSTM(units=2, input_shape=(back_windows, 1)))  # units = number of hidden units #50 for original
    return ts_data, ts_test, lstm_model


def model_free_feature_importance(pre_function, pre_list, true_y):
    """
    - Post-hoc feature importance: after randomly shuffling one feature, if the increase in MSE/MAE is small compared to the baseline, the feature has little impact and is less important
    :param pre_function: Prediction model
    :param pre_list: Prediction input list
    :param true_y: True Y values
    :return: MSE/MAE with each feature perturbed vs baseline; larger values indicate more important features
    """
    fea_nums = len(pre_list)  # number of features
    fea_importance_rmse, fea_importance_mae, fea_R2= [], [], []

    for i in range(fea_nums):
        pre_list_shuffle = deepcopy(pre_list) #pre_list.copy()

        base_pre = pre_function(pre_list)
        #base_line_rmse = mean_squared_error(true_y, base_pre.flatten())
        base_line_mae = mean_absolute_error(true_y, base_pre.flatten())
        base_line_R2 = r2_score(true_y, base_pre.flatten())  # r2_score(actual_values, predicted_values)
        total_rmse = 0.0
        total_mae = 0.0
        total_R2 = 0.0
        num_rep = 20  #100?
        for rep in range (num_rep):
            np.random.shuffle(pre_list_shuffle[i]) #pre_list_shuffle has already shuffled
            #print("XX",pre_list_shuffle[i])
            shuffle_pre = pre_function(pre_list_shuffle)
            #shuffle_line_rmse = mean_squared_error(true_y,shuffle_pre.flatten())
            shuffle_line_mae =  mean_absolute_error(true_y, shuffle_pre.flatten())
            shuffle_line_R2 = r2_score(true_y, shuffle_pre.flatten())
            pre_list_shuffle = deepcopy(pre_list) # reset pre_list_shuffle to default

            #total_rmse += shuffle_line_rmse
            total_mae += shuffle_line_mae
            total_R2 += shuffle_line_R2
        # take average, substracted by the baseline
        #rmse_score = base_line_rmse - total_rmse / num_rep
        mae_score = base_line_mae - total_mae / num_rep
        R2_score = base_line_R2 - total_R2 / num_rep

        fea_importance_rmse.append(base_line_mae) # let rmse be the baseline
        fea_importance_mae.append(mae_score)
        fea_R2.append(R2_score)

    return pd.DataFrame({'特征重要性RMSE': fea_importance_rmse, '特征重要性MAE': fea_importance_mae, '特征重要性R2': fea_R2})


def mutil_lstm(back_windows, x_df, pre_x, y):
    """
    - Multivariate LSTM modeling
    :param back_windows: Look-back window length
    :param x_df: Training features X
    :param pre_x: Features X for the most recent period (for prediction)
    :param y: Target
    :return: Predictions and feature-importance shapes
    """
    assert back_windows < len(y)  # Ensure the look-back window is smaller than the length of Y

    n, p = x_df.shape
    # 1. Construct time-series inputs for X and build LSTM models
    ts_train_list, ts_test_list, model_list = [], [], []
    for x_i in range(p):
        ts_train, ts_test, lstm_model = single_lstm(back_windows, x_df.iloc[:, x_i].tolist(),
                                                    pre_x.iloc[:, x_i].tolist()[0])
        ts_train_list.append(ts_train)
        ts_test_list.append(ts_test)
        model_list.append(lstm_model)
    ts_y = y.values.tolist()[back_windows:]
    ts_y = np.array(ts_y, dtype=np.float32)

    # 2.Concatenation layer
    concat_layer = tf.keras.layers.concatenate([m.output for m in model_list])
    dense_layer = tf.keras.layers.Dense(units=2)(concat_layer)
    output_layer = tf.keras.layers.Dense(units=1)(dense_layer)

    # 3. Define, compile, and train the model
    model = tf.keras.models.Model(inputs=[m.input for m in model_list], outputs=output_layer)   # Define the model

    model.compile(optimizer=tf.keras.optimizers.Adam(0.01), loss='mse')  # Compile the model

    model.fit(ts_train_list, ts_y, epochs=500)  # Train the model (200 epochs)

    # 4.Predict the next value
    next_value = model.predict([[np.reshape(test_x, (1, back_windows, 1))] for test_x in ts_test_list])

    # 5. Feature importance
    fea_importance = model_free_feature_importance(model.predict, ts_train_list, ts_y)
    fea_importance['特征'] = x_df.columns

    return next_value, fea_importance[['特征', '特征重要性RMSE', '特征重要性MAE', '特征重要性R2']]


def panel_deep_learning(dl_train, dl_test, dl_y):
    """
    - Deep learning modeling and prediction
    :param dl_train: Panel training data (first T-1 periods)
    :param dl_test: Panel test/prediction data (T-th period)
    :param dl_y: Target Y
    :return: RMSE and MAE
    """
    dl_train_df, dl_test_df = dl_train.copy(), dl_test.copy()
    x_col_name = dl_train_df.columns.difference([dl_y])  # 特征X
    all_entry = list(set([i[0] for i in dl_train_df.index]))
    #print(all_entry)
    #k = dl_test_df.loc[('Heilongjiang',)].sort_index(ascending=True)
    #print(k[dl_y].values[0])
    label_y, predict_y = [], []
    dl_fea_importance_df = pd.DataFrame()
    for entry in all_entry:  #total of 30 entries (30 provinces)
        entry_train_df = dl_train_df.loc[(entry,)].sort_index(ascending=True)
        entry_test_df = dl_test_df.loc[(entry,)].sort_index(ascending=True)

        pre_y, fea_importance = mutil_lstm(3, entry_train_df[x_col_name], entry_test_df[x_col_name],
                                           entry_train_df[dl_y])
        predict_y.append(pre_y[0][0])
        label_y.append(entry_test_df[dl_y].values[0])
        fea_importance['省份'] = entry
        dl_fea_importance_df = pd.concat([dl_fea_importance_df, fea_importance], axis=0)

    panel_rmse, panel_mae = np.sqrt(mean_squared_error(label_y, predict_y)), mean_absolute_error(label_y, predict_y)
    dl_pre_df = pd.DataFrame({'省份': all_entry, '真实值': label_y, '预测值': predict_y})
    return panel_rmse, panel_mae, dl_pre_df, dl_fea_importance_df



if __name__ == '__main__':

    #my_wd = r'D:/hml/w20230619/Carbon and Energy'
    my_wd = r'E:/Carbon.energy research March'
    try:
        my_data = pd.read_csv(my_wd + r'/train_data.csv')
        print('已经预处理过，直接读取，若修改data_ETL函数则需要删除csv文件')
    except FileNotFoundError:
        my_data = data_ETL(my_wd)
        print('数据预处理完成')
    my_data = my_data.sort_values('year')


    x_names = ['Raw Coal', 'Cleaned Coal', 'Other Washed Coal', 'Briquettes', 'Coke',
               'Coke Oven Gas', 'Other Gas', 'Other Coking Products', 'Crude Oil',
               'Gasoline', 'Kerosene', 'Diesel Oil', 'Fuel Oil', 'LPG', 'Refinery Gas',
               'Other Petroleum Products', 'Natural Gas', 'Heat', 'Electricity',
               'Other Energy', 'forest_coverage_rate']

    """x_names = ['Raw Coal', 'Cleaned Coal',
               'Crude Oil',
               'Electricity', 'Kerosene', 'Natural Gas', 'Heat',
               'Other Energy', 'forest_coverage_rate']"""
    #x_names = ['Raw Coal', 'Electricity', 'Crude Oil', 'Natural Gas','forest_coverage_rate']
    #x_names = ['tot_consumption', 'forest_coverage_rate']
    all_provence = list(set(my_data.area))
    all_year = list(set(my_data.year))
    y_name_list = ['gdp', 'tot_emissions']
    target, model_name, rmse, mae = [], [], [], []
    for y_name in y_name_list:

        scaler_train, scaler_test = panel_data_treat(my_data, x_names, y_name)


        rmse_temp, mae_temp, pre_df, fea_importance_df = panel_deep_learning(scaler_train, scaler_test, y_name)
        fea_importance_df.to_csv(my_wd + r'/DeepLearning/' + y_name + '_deep_learning_params.csv', index=False, encoding='utf_8_sig')
        pre_df.to_csv(my_wd + r'/DeepLearning/' + y_name + '_deep_learning_pre.csv', index=False, encoding='utf_8_sig')
        target.append(y_name)
        model_name.append('深度学习模型')
        rmse.append(rmse_temp)
        mae.append(mae_temp)

