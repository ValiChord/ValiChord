This folder contains the Python / R Markdown / Jupyter code used for the
deep learning analyses in our manuscript. The deep learning component
produces:

(1) Model-based feature importance results used for Figure 6
(2) Prediction performance results across multiple scenarios used for Figure 7
(3) Supporting map/plot scripts to visualize outputs for the paper


A) Input data
All scripts use the same input dataset: train_data.csv.

B) Deep learning model scripts (Python)
1. Deeplearning(All_Feature).py
Purpose:
Runs the full-feature deep learning model and exports results used to
create Figure 6A and Figure 6B (feature-importance maps/plots).

Output:

gdp_deep_learning_params.csv

tot_emissions_deep_learning_params.csv

gdp_deep_learning_pre.csv

tot_emissions_deep_learning_pre.csv
(Exact output folder depends on the path settings in the script.)

Used by:

Chinamap_deeplearning_results_gdp.Rmd

Chinamap_deeplearning_results_emission.Rmd


2. Deeplearning.py
Purpose:
Updated version that selects a smaller set of predictors of interest (based on feature importance)
and exports results used to create Figure 6C and Figure 6D.

Output:

gdp_deep_learning_params.csv

tot_emissions_deep_learning_params.csv

gdp_deep_learning_pre.csv

tot_emissions_deep_learning_pre.csv
(Written to the "DeepLearning(updated)" directory in your current setup.)

Used by:

Deeplearning_updated.Rmd


3. Deeplearning_scenarios.py
Purpose:
Runs the deep learning model under multiple predictor scenarios
(ablation / subset experiments) and exports the scenario prediction
outputs used for Figure 7.

Output:
A set of CSV files such as:
- tot_emissions_deep_learning_pre.csv
- tot_emissions_deep_learning_pre(without_forest).csv
- tot_emissions_deep_learning_pre(only_electricity).csv
- tot_emissions_deep_learning_pre(only_gasoline).csv
- tot_emissions_deep_learning_pre(only_forest_cover).csv
- ... (and corresponding GDP versions)
(Exact naming depends on the script version.)

Used by:

Deeplearning_updated.ipynb


C) Visualization scripts (R Markdown / Jupyter)

Chinamap_deeplearning_results_gdp.Rmd
Purpose:
Reads deep learning output CSV(s) and generates the GDP feature
importance map/plots for Figure 6A/6B.

Chinamap_deeplearning_results_emission.Rmd
Purpose:
Reads deep learning output CSV(s) and generates the emissions feature
importance map/plots for Figure 6A/6B.

Deeplearning_updated.Rmd
Purpose:
Reads the "updated" deep learning output and generates the feature
importance plots for Figure 6C/6D.

Deeplearning_updated.ipynb
Purpose:
Reads the scenario output CSVs from Deeplearning_scenarios.py and
generates the Figure 7 plots (predicted vs actual comparisons across
scenarios).


FIGURE MAPPING (MANUSCRIPT)

Figure 6A and 6B:
Produced from outputs of Deeplearning(All_Feature).py and plotted via:
* Chinamap_deeplearning_results_gdp.Rmd
* Chinamap_deeplearning_results_emission.Rmd

Figure 6C and 6D:
Produced from outputs of Deeplearning.py and plotted via:
* Deeplearning_updated.Rmd

Figure 7:
Produced from outputs of Deeplearning_scenarios.py and plotted via:
* Deeplearning_updated.ipynb


SOFTWARE REQUIREMENTS

A) Python environment
Recommended: Python 3.10 or 3.11 with a virtual environment (venv).

Core Python packages and recommended package version:
 - Python: recommended 3.10 (see TensorFlow note below)
 - tensorflow        == 2.11.0
 - numpy             == 1.21.6
 - pandas            == 1.3.5
 - scipy             == 1.7.3
 - scikit-learn      == 1.0.2
 - matplotlib        == 3.5.3

TensorFlow 2.11.0 is best supported on Python 3.10 (and may not install
cleanly on newer Python versions). If a user uses Python 3.11+, they
may need a newer TensorFlow version, which can lead to minor differences
in warnings or behavior. The paper results are based on the versions
listed above. In our testing, TensorFlow 2.15.0 also runs successfully,
though minor differences in warnings and/or numerical results may occur.


IMPORTANT: PATHS AND RUNNING ON ANOTHER MACHINE

Several scripts currently use ABSOLUTE PATHS, for example:

my_wd = r"E:/Carbon.energy research March"
my_data = pd.read_csv(my_wd + r"/train_data.csv")

Users will need to change these paths. Recommended approach:

Place train_data.csv in the same folder as the scripts, then use:
my_wd = r"."
my_data = pd.read_csv("train_data.csv")

Or set my_wd to the user's local folder containing train_data.csv.

Also check the output directories used in to_csv(), for example:
"/DeepLearning/"
"/DeepLearning(updated)/"
"/DeepLearning_Scenario(1)/"

If you have questions or run into issues reproducing the results, please
contact:

Zhelin Sheng
Zhelin_Sheng@URMC.Rochester.edu