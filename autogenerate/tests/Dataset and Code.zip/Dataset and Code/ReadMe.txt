This top-level folder contains the code and data used to reproduce the main
analyses in our manuscript. There are two main methodological components:

(1) Deep learning analyses (prediction + feature importance + scenarios)
(2) Multispatial CCM (mCCM) and time-delayed mCCM analyses (causal analysis)


CCM part/
Contains the R Markdown (.Rmd) scripts for multispatial CCM (mCCM) and
time-delayed mCCM. These scripts generate the causal analysis plots used
in the manuscript (see the ReadMe.txt inside this folder for details and
run instructions).

DeepLearning part/
Contains Python scripts plus R Markdown / Jupyter files for the deep
learning models. These scripts generate feature-importance and prediction
results used in the manuscript (see the ReadMe.txt inside this folder for
details and run instructions).

train_data.csv
The original dataset used by BOTH the CCM and Deep Learning code.